//#include <iostream>
//using namespace std;
//int main()
//{
//	auto a = 10;	// int
//	auto b = 3.14;	// double
//	auto c = 'A';	// char
//	
//
//	cout << a << " " << b << " " << c;
//	cout << typeid(c).name();
//}
//
//
//#include <iostream>
//using namespace std;
//int main()
//{
//    int a = 10;
//    decltype(a) b=44.8;
//    cout << b << endl;
//    cout << typeid(b).name();
//}
