//#include <iostream>
//using namespace std;
//
//int main()
//{
//    int x = 90;
//    string c = "Bosch";
//    auto add = [&x,c](int a, int b)
//        {
//            x = 999;
//            cout << c;
//            a + b + x;
//            return a + b;
//        };
//
//    cout << add(3, 4);
//}
//
//#include <iostream>
//#include <functional>
//using namespace std;
//
//int addme(int a, int b)
//{
//    return a + b;
//}
//
//int main()
//{
//    int x = 90;
//    string c = "Bosch";
//    function<int(int, int)> MyWay;
//
//    MyWay =
//        [&x, c](int a, int b)
//        {
//            x = 999;
//
//            cout << c << endl;
//
//            return a + b + x;
//        };
//
//    cout << MyWay(3, 4) << endl;
//
//    MyWay = addme;
//    cout << MyWay(20, 30);
//    cout << "Updated x : " << x;
//}

#include <iostream>
#include <functional>
using namespace std;

int add(int a, int b)
{
    return a + b;
}

int sub(int a, int b)
{
    return a - b;
}

class Multiply
{
public:
    int operator()(int a, int b)
    {
        return a * b;
    }
};

int main()
{
    function<int(int, int)> MyWay;

    int choice;

    cout << "1. Add" << endl;
    cout << "2. Subtract" << endl;
    cout << "3. Multiply" << endl;
    cout << "4. Custom Lambda" << endl;

    cin >> choice;

    switch (choice)
    {
    case 1:
        MyWay = add;
        break;

    case 2:
        MyWay = sub;
        break;

    case 3:
        MyWay = Multiply();
        break;

    case 4:
        MyWay =
            [](int a, int b)
            {
                return (a + b) * 10;
            };
        break;

    default:
        cout << "Invalid Choice";
        return 0;
    }

    cout << "Result : " << MyWay(10, 5);
}
