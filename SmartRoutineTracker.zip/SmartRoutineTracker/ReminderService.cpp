#include <iostream>
#include "ReminderService.h"

using namespace std;

void ReminderService::startService()
{
    cout << "\nReminder Service Started.\n";
}

void ReminderService::stopService()
{
    cout << "\nReminder Service Stopped.\n";
}

void ReminderService::executeNotifications()
{
    cout << "\nExecuting Notifications.\n";
}

void ReminderService::menu()
{
    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "        REMINDER MANAGEMENT\n";
        cout << "=========================================\n";

        cout << "1. Start Reminder Service\n";
        cout << "2. Stop Reminder Service\n";
        cout << "3. Execute Notifications\n";
        cout << "0. Back\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                startService();
                break;

            case 2:
                stopService();
                break;

            case 3:
                executeNotifications();
                break;

            case 0:
                break;

            default:
                cout << "Invalid Choice.\n";
        }

    } while(choice != 0);
}
