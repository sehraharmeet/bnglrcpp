#include <iostream>
#include "RoutineManager.h"

using namespace std;

void RoutineManager::addRoutine()
{
    Routine r;

    cout << "\nEnter ID : ";
    cin >> r.id;

    cin.ignore();

    cout << "Enter Title : ";
    getline(cin, r.title);

    cout << "Enter Category : ";
    getline(cin, r.category);

    cout << "Enter Priority : ";
    getline(cin, r.priority);

    routines.push_back(r);

    cout << "\nRoutine Added.\n";
}

void RoutineManager::viewRoutines()
{
    cout << "\n========== ROUTINES ==========\n";

    for(auto r : routines)
    {
        cout << "\nID       : " << r.id;
        cout << "\nTitle    : " << r.title;
        cout << "\nCategory : " << r.category;
        cout << "\nPriority : " << r.priority;
        cout << "\nStatus   : "
             << (r.completed ? "Completed" : "Pending");
        cout << "\n-----------------------------\n";
    }
}

void RoutineManager::markCompleted()
{
    int id;

    cout << "\nEnter Routine ID : ";
    cin >> id;

    for(auto &r : routines)
    {
        if(r.id == id)
        {
            r.completed = true;
            cout << "Routine Marked Completed.\n";
            return;
        }
    }

    cout << "Routine Not Found.\n";
}

void RoutineManager::deleteRoutine()
{
    int id;

    cout << "\nEnter Routine ID : ";
    cin >> id;

    for(int i = 0; i < routines.size(); i++)
    {
        if(routines[i].id == id)
        {
            routines.erase(routines.begin() + i);
            cout << "Routine Deleted.\n";
            return;
        }
    }

    cout << "Routine Not Found.\n";
}

void RoutineManager::menu()
{
    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "        ROUTINE MANAGEMENT\n";
        cout << "=========================================\n";

        cout << "1. Add Routine\n";
        cout << "2. View Routines\n";
        cout << "3. Mark Completed\n";
        cout << "4. Delete Routine\n";
        cout << "0. Back\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                addRoutine();
                break;

            case 2:
                viewRoutines();
                break;

            case 3:
                markCompleted();
                break;

            case 4:
                deleteRoutine();
                break;

            case 0:
                break;

            default:
                cout << "Invalid Choice.\n";
        }

    } while(choice != 0);
}
