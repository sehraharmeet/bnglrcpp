#include <iostream>
#include "ReportManager.h"

using namespace std;

void ReportManager::menu()
{
    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "        STATISTICS & REPORTS\n";
        cout << "=========================================\n";

        cout << "1. Total Routines\n";
        cout << "2. Completed Routines\n";
        cout << "3. Pending Routines\n";
        cout << "0. Back\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "\nTotal Routines Report.\n";
                break;

            case 2:
                cout << "\nCompleted Routines Report.\n";
                break;

            case 3:
                cout << "\nPending Routines Report.\n";
                break;

            case 0:
                break;

            default:
                cout << "Invalid Choice.\n";
        }

    } while(choice != 0);
}
