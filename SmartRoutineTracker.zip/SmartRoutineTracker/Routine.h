
#include <string>

using namespace std;

class Routine
{
public:
    int id;
    string title;
    string category;
    string priority;
    bool completed;

    Routine();
};

