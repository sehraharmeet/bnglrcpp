

class ReportManager
{
public:
    void menu();
};

