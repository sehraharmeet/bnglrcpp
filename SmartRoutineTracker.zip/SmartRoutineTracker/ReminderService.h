
class ReminderService
{
public:
    void startService();
    void stopService();
    void executeNotifications();
    void menu();
};

