#include <iostream>
#include "RoutineManager.h"
#include "ReminderService.h"
#include "ReportManager.h"
#include "DataManager.h"

using namespace std;

int main()
{
    RoutineManager routineManager;
    ReminderService reminderService;
    ReportManager reportManager;
    DataManager dataManager;

    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "     SMART DAILY ROUTINE TRACKER\n";
        cout << "=========================================\n";

        cout << "1. Routine Management\n";
        cout << "2. Reminder Management\n";
        cout << "3. Statistics & Reports\n";
        cout << "4. Data Management\n";
        cout << "0. Exit\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                routineManager.menu();
                break;

            case 2:
                reminderService.menu();
                break;

            case 3:
                reportManager.menu();
                break;

            case 4:
                dataManager.menu();
                break;

            case 0:
                cout << "\nThank You...\n";
                break;

            default:
                cout << "\nInvalid Choice.\n";
        }

    } while(choice != 0);

    return 0;
}
