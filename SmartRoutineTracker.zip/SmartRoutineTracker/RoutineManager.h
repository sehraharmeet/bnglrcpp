
#include <vector>
#include "Routine.h"

class RoutineManager
{
private:
    std::vector<Routine> routines;

public:
    void addRoutine();
    void viewRoutines();
    void markCompleted();
    void deleteRoutine();
    void menu();
};

